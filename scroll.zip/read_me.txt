Hi there thanks for downloading my assets

This asset was completed as part as a Freebie friday  request. Freebie friday requests are where I complete small game asset requests for free for all the game developer community. You can find more of my Freebie friday requests on my site https://www.gamedeveloperstudio.com You can also find more free assets on my site, and if you would like to support me and my  work you can find purchasable assets on my site too. 

Check out the website or my discord channel to see if Freebie friday is still running and when the next one is. To make your own requests come over to the discord channel: https://discord.gg/EVv7WUq 

Kind regards

Robert

www.gamedeveloperstudio.com
