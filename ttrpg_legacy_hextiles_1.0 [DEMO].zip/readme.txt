Thank you for downloading TTRPG LEGACY [HEX TILES] asset pack

Licence:
YOU CAN:

- Edit and use the asset in any commercial or non commercial project

YOU CAN'T:

- Use in Any Project related to NFTs or IA Picture Generator
- Distribute or sell, edited or not, parts or the entirety of an asset
(including all files inside the packs)

Please Credit Me with : [https://ddant1100.itch.io] or [Ddant1100]

For any question, bug, anything else you can contact me on :

https://ddant1100.itch.io

https://twitter.com/Ddant1100_Mf

https://www.instagram.com/ddant1100/